package com.example.sidepanel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val selected = (prefs.getString("apps", "") ?: "")
            .split(",").filter { it.isNotEmpty() }.toMutableList()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun addButton(label: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { onClick() }
            root.addView(b)
        }

        addButton("1) السماح بالعرض فوق التطبيقات") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        addButton("2) تفعيل خدمة إمكانية الوصول (لوضع التقسيم فقط)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val modeSwitch = Switch(this)
        modeSwitch.text = "وضع تقسيم الشاشة (بدل النافذة العائمة)"
        modeSwitch.isChecked = prefs.getString("mode", "float") == "split"
        modeSwitch.setOnCheckedChangeListener { _, on ->
            prefs.edit().putString("mode", if (on) "split" else "float").apply()
        }
        root.addView(modeSwitch)

        addButton("3) تشغيل اللوحة الجانبية") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "فعّل الخطوة 1 أولاً", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this, PanelService::class.java))
            }
        }
        addButton("إيقاف اللوحة") {
            stopService(Intent(this, PanelService::class.java))
        }

        val title = TextView(this)
        title.text = "اختر حتى 5 تطبيقات:"
        title.setPadding(0, pad, 0, pad)
        root.addView(title)

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        for ((pkg, label) in apps) {
            val cb = CheckBox(this)
            cb.text = label
            cb.isChecked = pkg in selected
            cb.setOnCheckedChangeListener { view, on ->
                if (on) {
                    if (pkg !in selected) {
                        if (selected.size >= 5) {
                            view.isChecked = false
                            Toast.makeText(this, "الحد الأقصى 5 تطبيقات", Toast.LENGTH_SHORT).show()
                            return@setOnCheckedChangeListener
                        }
                        selected.add(pkg)
                    }
                } else {
                    selected.remove(pkg)
                }
                prefs.edit().putString("apps", selected.joinToString(",")).apply()
            }
            root.addView(cb)
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }
}
