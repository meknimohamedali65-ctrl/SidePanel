package com.example.sidepanel

import android.accessibilityservice.AccessibilityService
import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class PanelService : Service() {

    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: View? = null
    private val density get() = resources.displayMetrics.density

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(1, buildNotification())
        addHandle()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        closePanel()
        handle?.let { wm.removeView(it) }
        handle = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("panel", "اللوحة الجانبية", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "panel")
            .setContentTitle("اللوحة الجانبية تعمل")
            .setSmallIcon(android.R.drawable.ic_menu_more)
            .build()
    }

    private fun overlayParams(flags: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags,
        PixelFormat.TRANSLUCENT
    )

    /** المقبض الصغير على حافة الشاشة اليمنى. */
    private fun addHandle() {
        val d = density
        val r = 28 * d
        val v = TextView(this)
        v.text = "‹"
        v.textSize = 24f
        v.gravity = Gravity.CENTER
        v.setTextColor(Color.WHITE)
        v.background = GradientDrawable().apply {
            setColor(0xAA222222.toInt())
            cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        }
        v.setOnClickListener { if (panel == null) openPanel() else closePanel() }

        val lp = overlayParams(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        lp.width = (28 * d).toInt()
        lp.height = (64 * d).toInt()
        lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        wm.addView(v, lp)
        handle = v
    }

    /** القائمة التي تحوي أيقونات التطبيقات المختارة. */
    private fun openPanel() {
        val d = density
        val pkgs = (getSharedPreferences("cfg", MODE_PRIVATE).getString("apps", "") ?: "")
            .split(",").filter { it.isNotEmpty() }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val p = (8 * d).toInt()
        box.setPadding(p, p, p, p)
        box.background = GradientDrawable().apply {
            setColor(0xEE222222.toInt())
            cornerRadius = 20 * d
        }

        if (pkgs.isEmpty()) {
            val t = TextView(this)
            t.text = "افتح التطبيق\nوأضف تطبيقات"
            t.setTextColor(Color.WHITE)
            box.addView(t)
        }

        for (pkg in pkgs) {
            val icon = try {
                packageManager.getApplicationIcon(pkg)
            } catch (e: Exception) {
                continue
            }
            val iv = ImageView(this)
            iv.setImageDrawable(icon)
            val size = (48 * d).toInt()
            val lp = LinearLayout.LayoutParams(size, size)
            val m = (6 * d).toInt()
            lp.setMargins(m, m, m, m)
            iv.layoutParams = lp
            iv.setOnClickListener {
                closePanel()
                launch(pkg)
            }
            box.addView(iv)
        }

        // لمسة خارج القائمة تغلقها
        box.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) closePanel()
            false
        }

        val lp = overlayParams(
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        )
        lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        lp.x = (32 * d).toInt()
        wm.addView(box, lp)
        panel = box
    }

    private fun closePanel() {
        panel?.let { wm.removeView(it) }
        panel = null
    }

    private fun launch(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val mode = getSharedPreferences("cfg", MODE_PRIVATE).getString("mode", "float")

        if (mode == "split") {
            val svc = SplitAccessibilityService.instance
            if (svc == null) {
                Toast.makeText(this, "فعّل خدمة إمكانية الوصول أولاً", Toast.LENGTH_LONG).show()
                return
            }
            svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            Handler(Looper.getMainLooper()).postDelayed({
                intent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                startActivity(intent)
            }, 800)
        } else {
            val dm = resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels
            val bounds = Rect(w / 10, h / 6, w * 9 / 10, h * 2 / 3)
            val opts = ActivityOptions.makeBasic().setLaunchBounds(bounds)
            startActivity(intent, opts.toBundle())
        }
    }
}
