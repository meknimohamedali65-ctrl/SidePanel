package com.example.sidepanel

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** خدمة فارغة؛ وظيفتها الوحيدة تنفيذ إجراء "تقسيم الشاشة". */
class SplitAccessibilityService : AccessibilityService() {
    companion object {
        var instance: SplitAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }
}
